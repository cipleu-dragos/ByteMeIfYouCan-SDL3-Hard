CMakeFiles\SDL3_Project_SelfContained.dir\main.cpp.obj.ddi: \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/main.cpp \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/iostream \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/requires_hosted.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/x86_64-w64-mingw32/bits/c++config.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/x86_64-w64-mingw32/bits/os_defines.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/x86_64-w64-mingw32/bits/cpu_defines.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/pstl/pstl_config.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/ostream \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/ostream.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/ios \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/iosfwd \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/stringfwd.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/memoryfwd.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/postypes.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/cwchar \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/wchar.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/corecrt.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/_mingw.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/_mingw_mac.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/_mingw_secapi.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/vadefs.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/sdks/_mingw_ddk.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/corecrt_stdio_config.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/corecrt_wstdlib.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/corecrt_wctype.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/_mingw_off_t.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/_mingw_stat64.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/swprintf.inl \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/sec_api/wchar_s.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/exception \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/exception.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/version.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/exception_ptr.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/exception_defines.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/cxxabi_init_exception.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/stddef.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/stddef.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/crtdefs.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/typeinfo \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/hash_bytes.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/new \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/move.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/type_traits \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/nested_exception.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/char_traits.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/compare \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/concepts \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/stl_construct.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/stl_iterator_base_types.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/iterator_concepts.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/ptr_traits.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/ranges_cmp.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/stl_iterator_base_funcs.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/concept_check.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/debug/assertions.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/localefwd.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/x86_64-w64-mingw32/bits/c++locale.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/clocale \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/locale.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/stdio.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/sec_api/stdio_s.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/cctype \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/ctype.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/ios_base.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/ext/atomicity.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/x86_64-w64-mingw32/bits/gthr.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/x86_64-w64-mingw32/bits/gthr-default.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/pthread.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/errno.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/sys/types.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/process.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/corecrt_startup.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/limits.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/syslimits.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/limits.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/signal.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/pthread_signal.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/time.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/sys/timeb.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/sec_api/sys/timeb_s.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/_timeval.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/pthread_time.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/pthread_compat.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/sched.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/pthread_unistd.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/x86_64-w64-mingw32/bits/atomic_word.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/locale_classes.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/string \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/allocator.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/x86_64-w64-mingw32/bits/c++allocator.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/new_allocator.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/functexcept.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/cpp_type_traits.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/ostream_insert.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/cxxabi_forced.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/stl_iterator.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/ext/type_traits.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/stl_function.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/backward/binders.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/ext/numeric_traits.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/stl_algobase.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/stl_pair.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/utility.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/debug/debug.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/predefined_ops.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bit \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/refwrap.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/invoke.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/range_access.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/initializer_list \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/basic_string.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/ext/alloc_traits.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/alloc_traits.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/string_view \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/functional_hash.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/ranges_base.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/max_size_type.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/numbers \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/string_view.tcc \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/ext/string_conversions.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/cstdlib \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/stdlib.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/sec_api/stdlib_s.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/stdlib.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/malloc.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/mm_malloc.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/std_abs.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/cstdio \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/cerrno \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/charconv.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/basic_string.tcc \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/memory_resource.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/cstddef \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/uses_allocator.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/uses_allocator_args.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/tuple \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/ranges_util.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/locale_classes.tcc \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/system_error \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/x86_64-w64-mingw32/bits/error_constants.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/stdexcept \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/streambuf \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/streambuf.tcc \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/basic_ios.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/locale_facets.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/cwctype \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/wctype.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/x86_64-w64-mingw32/bits/ctype_base.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/streambuf_iterator.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/x86_64-w64-mingw32/bits/ctype_inline.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/locale_facets.tcc \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/basic_ios.tcc \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/ostream.tcc \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/istream \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/istream.tcc \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/vector \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/stl_uninitialized.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/stl_vector.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/stl_bvector.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/vector.tcc \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/algorithm \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/stl_algo.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/algorithmfwd.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/stl_heap.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/uniform_int_dist.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/stl_tempbuf.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/ranges_algo.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/ranges_algobase.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/pstl/glue_algorithm_defs.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/pstl/execution_defs.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/cmath \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/math.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/specfun.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/limits \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/tr1/gamma.tcc \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/tr1/special_function_util.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/tr1/bessel_function.tcc \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/tr1/beta_function.tcc \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/tr1/ell_integral.tcc \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/tr1/exp_integral.tcc \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/tr1/hypergeometric.tcc \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/tr1/legendre_function.tcc \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/tr1/modified_bessel_func.tcc \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/tr1/poly_hermite.tcc \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/tr1/poly_laguerre.tcc \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/tr1/riemann_zeta.tcc \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/random \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/cstdint \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/stdint.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/stdint.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/random.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/x86_64-w64-mingw32/bits/opt_random.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/pmmintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/emmintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/xmmintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/mmintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/mwaitintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/random.tcc \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/numeric \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/bits/stl_numeric.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/pstl/glue_numeric_defs.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_stdinc.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_platform_defines.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/stdarg.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/stdarg.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/_mingw_stdarg.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/string.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/sec_api/string_s.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_begin_code.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_close_code.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_assert.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/intrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/setjmp.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/psdk_inc/intrin-impl.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/x86intrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/x86gprintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/ia32intrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/adxintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/bmiintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/bmi2intrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/cetintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/cldemoteintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/clflushoptintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/clwbintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/clzerointrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/cmpccxaddintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/enqcmdintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/fxsrintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/lzcntintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/lwpintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/movdirintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/mwaitxintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/pconfigintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/popcntintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/pkuintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/prfchiintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/raointintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/rdseedintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/rtmintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/serializeintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/sgxintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/tbmintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/tsxldtrkintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/uintrintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/waitpkgintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/wbnoinvdintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/xsaveintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/xsavecintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/xsaveoptintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/xsavesintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/xtestintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/hresetintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/usermsrintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/immintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/tmmintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/smmintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/wmmintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avxintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avxvnniintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avxifmaintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avxvnniint8intrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avxvnniint16intrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx2intrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512fintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512cdintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512vlintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512bwintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512dqintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512vlbwintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512vldqintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512ifmaintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512ifmavlintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512vbmiintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512vbmivlintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512vpopcntdqintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512vbmi2intrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512vbmi2vlintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512vnniintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512vnnivlintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512vpopcntdqvlintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512bitalgintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512bitalgvlintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512vp2intersectintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512vp2intersectvlintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512fp16intrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512fp16vlintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/shaintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/sm3intrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/sha512intrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/sm4intrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/fmaintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/f16cintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/gfniintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/vaesintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/vpclmulqdqintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512bf16vlintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx512bf16intrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avxneconvertintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/amxtileintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/amxint8intrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/amxbf16intrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/amxcomplexintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/amxavx512intrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/amxtf32intrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/amxtransposeintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/amxfp8intrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/prfchwintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/keylockerintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/amxfp16intrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx10_2mediaintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx10_2-512mediaintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx10_2convertintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx10_2-512convertintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx10_2bf16intrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx10_2-512bf16intrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx10_2satcvtintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx10_2-512satcvtintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx10_2minmaxintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx10_2-512minmaxintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx10_2copyintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/movrsintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/amxmovrsintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/mm3dnow.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/fma4intrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/ammintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/xopintrin.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/cpuid.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_asyncio.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_atomic.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_audio.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_endian.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_error.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_mutex.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_thread.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_properties.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_iostream.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_bits.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_blendmode.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_camera.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_pixels.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_surface.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_rect.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_clipboard.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_cpuinfo.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_dialog.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_video.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_dlopennote.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_events.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_gamepad.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_guid.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_joystick.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_power.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_sensor.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_keyboard.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_keycode.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_scancode.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_mouse.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_pen.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_touch.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_filesystem.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_gpu.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_haptic.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_hidapi.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_hints.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_init.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_loadso.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_locale.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_log.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_messagebox.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_metal.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_misc.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_platform.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_process.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_render.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_storage.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_system.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_time.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_timer.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_tray.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_version.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/SDL3/include/SDL3/SDL_oldnames.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/rectangle.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/glm.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/detail/_fixes.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/detail/setup.hpp \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/cassert \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/assert.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/simd/platform.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/climits \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/c++/cfloat \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/lib/gcc/x86_64-w64-mingw32/15.2.0/include/float.h \
 C:/Program\ Files/JetBrains/CLion\ 2026.2.3.1/bin/mingw/x86_64-w64-mingw32/include/float.h \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/fwd.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/detail/qualifier.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/detail/setup.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/vec2.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/vector_bool2.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/detail/type_vec2.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/detail/type_vec2.inl \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/detail/compute_vector_relational.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/vector_bool2_precision.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/vector_float2.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/vector_float2_precision.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/vector_double2.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/vector_double2_precision.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/vector_int2.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/vector_int2_sized.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/scalar_int_sized.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/detail/setup.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/vector_uint2.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/vector_uint2_sized.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/scalar_uint_sized.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/vec3.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/vector_bool3.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/detail/type_vec3.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/detail/type_vec3.inl \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/vector_bool3_precision.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/vector_float3.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/vector_float3_precision.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/vector_double3.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/vector_double3_precision.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/vector_int3.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/vector_int3_sized.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/vector_uint3.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/vector_uint3_sized.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/vec4.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/vector_bool4.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/detail/type_vec4.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/detail/type_vec4.inl \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/vector_bool4_precision.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/vector_float4.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/vector_float4_precision.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/vector_double4.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/vector_double4_precision.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/vector_int4.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/vector_int4_sized.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/vector_uint4.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/vector_uint4_sized.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/mat2x2.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/matrix_double2x2.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/detail/type_mat2x2.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/detail/type_mat2x2.inl \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/matrix.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/mat2x3.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/matrix_double2x3.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/detail/type_mat2x3.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/detail/type_mat2x3.inl \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/matrix_double2x3_precision.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/matrix_float2x3.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/matrix_float2x3_precision.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/mat2x4.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/matrix_double2x4.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/detail/type_mat2x4.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/detail/type_mat2x4.inl \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/matrix_double2x4_precision.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/matrix_float2x4.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/matrix_float2x4_precision.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/mat3x2.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/matrix_double3x2.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/detail/type_mat3x2.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/detail/type_mat3x2.inl \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/matrix_double3x2_precision.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/matrix_float3x2.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/matrix_float3x2_precision.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/mat3x3.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/matrix_double3x3.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/detail/type_mat3x3.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/detail/type_mat3x3.inl \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/matrix_double3x3_precision.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/matrix_float3x3.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/matrix_float3x3_precision.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/mat3x4.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/matrix_double3x4.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/detail/type_mat3x4.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/detail/type_mat3x4.inl \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/matrix_double3x4_precision.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/matrix_float3x4.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/matrix_float3x4_precision.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/mat4x2.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/matrix_double4x2.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/detail/type_mat4x2.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/detail/type_mat4x2.inl \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/matrix_double4x2_precision.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/matrix_float4x2.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/matrix_float4x2_precision.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/mat4x3.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/matrix_double4x3.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/detail/type_mat4x3.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/detail/type_mat4x3.inl \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/matrix_double4x3_precision.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/matrix_float4x3.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/matrix_float4x3_precision.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/mat4x4.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/matrix_double4x4.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/detail/type_mat4x4.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/detail/type_mat4x4.inl \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/matrix_double4x4_precision.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/matrix_float4x4.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/matrix_float4x4_precision.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/detail/func_matrix.inl \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/geometric.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/detail/func_geometric.inl \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/exponential.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/detail/type_vec1.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/detail/type_vec1.inl \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/detail/func_exponential.inl \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/vector_relational.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/detail/func_vector_relational.inl \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/detail/_vectorize.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/common.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/detail/func_common.inl \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/detail/compute_common.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/matrix_double2x2_precision.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/matrix_float2x2.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/ext/matrix_float2x2_precision.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/trigonometric.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/detail/func_trigonometric.inl \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/packing.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/detail/func_packing.inl \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/detail/type_half.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/detail/type_half.inl \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/integer.hpp \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/glm/detail/func_integer.inl \
 C:/Users/Dragos/Desktop/SDL3_Project_SelfContained/circle.h
