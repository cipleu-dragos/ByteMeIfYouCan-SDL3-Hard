#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <random>
#include <SDL3/SDL.h>
#include "rectangle.h"
#include "circle.h"
#include "glm/glm.hpp"

int windowWidth{ 700 };
int windowHeight{ 800 };

constexpr float VERTICAL_SCROLLING_SPEED{ 100.0f };
constexpr int VERTICAL_SCROLLING_GRID_SQUARE_SIZE{ 20 };
std::vector<Rectangle> scrollingGrid;

float DT{ 0.01f };
Uint64 startTime{ 0 };
Uint64 endTime{ 0 };

SDL_Window *window{ nullptr };
SDL_Renderer *renderer{ nullptr };
SDL_Event currentEvent;
SDL_Color backgroundColor{ 255, 255, 255, 255 };

bool quit{ false };
float displayScale{ 1.0f };

constexpr float SHIP_WIDTH = 50.0f;
constexpr float SHIP_HEIGHT = 50.0f;
constexpr float SHIP_ACCELERATION = 400.0f;
constexpr float SHIP_DECELERATION = 800.0f;
constexpr float SHIP_MAX_VELOCITY = 500.0f;

constexpr float PLAYER_PROJECTILE_SPEED = 500.0f;
constexpr float PLAYER_PROJECTILE_RADIUS = 10.0f;
constexpr float PLAYER_FIRE_RATE = 0.3f;

constexpr float ENEMY_WIDTH = 50.0f;
constexpr float ENEMY_HEIGHT = 50.0f;
constexpr float ENEMY_PROJECTILE_SPEED = 100.0f;
constexpr float ENEMY_PROJECTILE_RADIUS = 10.0f;
constexpr float ENEMY_FIRE_RATE = 3.0f;
constexpr float ENEMY_START_SHOOT_DELAY = 1.0f;

enum class GameState {
    RUNNING,
    WON,
    LOST
};

GameState gameState{ GameState::RUNNING };

Rectangle playerShip;
glm::vec2 mouseRelativeAccumulator{ 0.0f, 0.0f };
bool mouseMovedThisFrame{ false };
bool leftMouseButtonPressed{ false };
float playerShootCooldownTimer{ PLAYER_FIRE_RATE };

struct Enemy {
    Rectangle rect;
    int sliceIndex{ 0 };
    float timeSinceEntered{ 0.0f };
    float shootTimer{ 0.0f };
    bool hasStartedShooting{ false };
};

std::vector<Enemy> enemies;

struct SliceInfo {
    bool hasActiveEnemy{ false };
    float clearTimer{ 0.0f };
};
SliceInfo slices[3];

std::vector<Circle> playerProjectiles;
std::vector<Circle> enemyProjectiles;

int totalEnemiesDestroyed{ 0 };

std::mt19937 rng(1337);

float randomFloat(float minVal, float maxVal) {
    std::uniform_real_distribution<float> dist(minVal, maxVal);
    return dist(rng);
}

void initScrollingRectangles() {
    scrollingGrid.clear();
    int numGridRectangles = (windowHeight / VERTICAL_SCROLLING_GRID_SQUARE_SIZE) / 2 + 2;

    for (int i = 0; i < numGridRectangles; i++) {
        Rectangle newGridRectangleLeft, newGridRectangleRight;

        newGridRectangleLeft.width = newGridRectangleLeft.height = VERTICAL_SCROLLING_GRID_SQUARE_SIZE;
        newGridRectangleLeft.pos.x = newGridRectangleLeft.width / 2.0f;
        newGridRectangleLeft.pos.y = windowHeight - newGridRectangleLeft.height / 2.0f - 2.0f * i * newGridRectangleLeft.height;
        newGridRectangleLeft.vel = glm::vec2(0.0f, VERTICAL_SCROLLING_SPEED);
        newGridRectangleLeft.color = SDL_Color{ 235, 235, 235, 255 };

        newGridRectangleRight.width = newGridRectangleRight.height = VERTICAL_SCROLLING_GRID_SQUARE_SIZE;
        newGridRectangleRight.pos.x = windowWidth - newGridRectangleRight.width / 2.0f;
        newGridRectangleRight.pos.y = windowHeight - newGridRectangleRight.height / 2.0f - 2.0f * i * newGridRectangleRight.height;
        newGridRectangleRight.vel = glm::vec2(0.0f, VERTICAL_SCROLLING_SPEED);
        newGridRectangleRight.color = SDL_Color{ 235, 235, 235, 255 };

        scrollingGrid.push_back(newGridRectangleLeft);
        scrollingGrid.push_back(newGridRectangleRight);
    }
}

void spawnEnemyInSlice(int sliceIndex) {
    float sliceWidth = static_cast<float>(windowWidth) / 3.0f;
    float minX = sliceIndex * sliceWidth + ENEMY_WIDTH / 2.0f;
    float maxX = (sliceIndex + 1) * sliceWidth - ENEMY_WIDTH / 2.0f;
    float posX = randomFloat(minX, maxX);
    float posY = -ENEMY_HEIGHT / 2.0f;

    float speedY = randomFloat(50.0f, 150.0f);

    Enemy enemy;
    enemy.rect = Rectangle(ENEMY_WIDTH, ENEMY_HEIGHT, glm::vec2(posX, posY), SDL_Color{ 255, 165, 0, 255 });
    enemy.rect.vel = glm::vec2(0.0f, speedY);
    enemy.sliceIndex = sliceIndex;
    enemy.timeSinceEntered = 0.0f;
    enemy.shootTimer = 0.0f;
    enemy.hasStartedShooting = false;

    enemies.push_back(enemy);
    slices[sliceIndex].hasActiveEnemy = true;
    slices[sliceIndex].clearTimer = 0.0f;
}

void spawnPlayerProjectile() {
    Circle proj;
    proj.radius = PLAYER_PROJECTILE_RADIUS;
    proj.pos = playerShip.pos;
    proj.vel = glm::vec2(0.0f, -PLAYER_PROJECTILE_SPEED);
    proj.color = SDL_Color{ 255, 0, 0, 255 };
    playerProjectiles.push_back(proj);
}

void spawnEnemyProjectiles(const Enemy& enemy) {
    glm::vec2 toPlayer = playerShip.pos - enemy.rect.pos;
    float dist = glm::length(toPlayer);
    if (dist < 0.0001f) {
        toPlayer = glm::vec2(0.0f, 1.0f);
    } else {
        toPlayer /= dist;
    }

    constexpr float DEG_TO_RAD = 3.14159265358979323846f / 180.0f;
    float baseAngle = std::atan2(toPlayer.y, toPlayer.x);
    float angleOffsets[3] = { 0.0f, 15.0f * DEG_TO_RAD, -15.0f * DEG_TO_RAD };

    for (int i = 0; i < 3; i++) {
        float angle = baseAngle + angleOffsets[i];
        glm::vec2 vel(std::cos(angle) * ENEMY_PROJECTILE_SPEED,
                      std::sin(angle) * ENEMY_PROJECTILE_SPEED);

        Circle proj;
        proj.radius = ENEMY_PROJECTILE_RADIUS;
        proj.pos = enemy.rect.pos;
        proj.vel = vel;
        proj.color = SDL_Color{ 255, 0, 255, 255 };
        enemyProjectiles.push_back(proj);
    }
}

void activateRepulsor() {
    for (auto& proj : enemyProjectiles) {
        glm::vec2 pushDir = proj.pos - playerShip.pos;
        float dist = glm::length(pushDir);
        if (dist > 0.0001f) {
            pushDir /= dist;
        } else {
            pushDir = glm::vec2(0.0f, -1.0f);
        }
        proj.vel += pushDir * 20.0f;
    }
}

bool checkCircleRectangleCollision(const Circle& circle, const Rectangle& rect) {
    float halfW = rect.width / 2.0f;
    float halfH = rect.height / 2.0f;

    float closestX = std::clamp(circle.pos.x, rect.pos.x - halfW, rect.pos.x + halfW);
    float closestY = std::clamp(circle.pos.y, rect.pos.y - halfH, rect.pos.y + halfH);

    float distX = circle.pos.x - closestX;
    float distY = circle.pos.y - closestY;

    return (distX * distX + distY * distY) <= (circle.radius * circle.radius);
}

bool checkRectangleRectangleCollision(const Rectangle& a, const Rectangle& b) {
    return (std::abs(a.pos.x - b.pos.x) <= (a.width + b.width) / 2.0f) &&
           (std::abs(a.pos.y - b.pos.y) <= (a.height + b.height) / 2.0f);
}

void triggerGameOver(bool won) {
    if (gameState != GameState::RUNNING) return;

    if (won) {
        gameState = GameState::WON;
        playerShip.color = SDL_Color{ 0, 0, 255, 255 };
    } else {
        gameState = GameState::LOST;
        playerShip.color = SDL_Color{ 255, 0, 0, 255 };
    }

    playerShip.vel = glm::vec2(0.0f, 0.0f);

    enemies.clear();
    playerProjectiles.clear();
    enemyProjectiles.clear();
}

void resetGame() {
    if (gameState == GameState::RUNNING) return;

    gameState = GameState::RUNNING;
    totalEnemiesDestroyed = 0;

    playerShip.width = SHIP_WIDTH;
    playerShip.height = SHIP_HEIGHT;
    playerShip.pos = glm::vec2(windowWidth / 2.0f, windowHeight - SHIP_HEIGHT / 2.0f);
    playerShip.vel = glm::vec2(0.0f, 0.0f);
    playerShip.color = SDL_Color{ 0, 255, 0, 255 };

    playerShootCooldownTimer = PLAYER_FIRE_RATE;
    leftMouseButtonPressed = false;
    mouseMovedThisFrame = false;
    mouseRelativeAccumulator = glm::vec2(0.0f, 0.0f);

    playerProjectiles.clear();
    enemyProjectiles.clear();
    enemies.clear();

    for (int i = 0; i < 3; i++) {
        slices[i].hasActiveEnemy = false;
        slices[i].clearTimer = 0.0f;
        spawnEnemyInSlice(i);
    }

    initScrollingRectangles();
}

bool initWindow() {
    bool success{ true };

    if (!SDL_Init(SDL_INIT_VIDEO)) {
        SDL_Log("SDL initialization failed: %s\n", SDL_GetError());
        return false;
    }

    displayScale = SDL_GetDisplayContentScale(1);
    if (displayScale <= 0.0f) displayScale = 1.0f;

    if (!SDL_CreateWindowAndRenderer(
        "A Blast From The Past",
        static_cast<int>(displayScale * windowWidth),
        static_cast<int>(displayScale * windowHeight),
        SDL_WINDOW_RESIZABLE,
        &window, &renderer)) {
        SDL_Log("Failed to create window and renderer: %s\n", SDL_GetError());
        return false;
    }

    SDL_SetRenderScale(renderer, displayScale, displayScale);
    SDL_SetRenderDrawColor(renderer, backgroundColor.r, backgroundColor.g, backgroundColor.b, backgroundColor.a);
    SDL_RenderClear(renderer);

    SDL_SetWindowRelativeMouseMode(window, true);

    return success;
}

void cleanup() {
    if (renderer) {
        SDL_DestroyRenderer(renderer);
        renderer = nullptr;
    }
    if (window) {
        SDL_DestroyWindow(window);
        window = nullptr;
    }
    SDL_Quit();
}

void processEvents() {
    mouseMovedThisFrame = false;
    mouseRelativeAccumulator = glm::vec2(0.0f, 0.0f);

    while (SDL_PollEvent(&currentEvent)) {
        if (currentEvent.type == SDL_EVENT_QUIT) {
            quit = true;
        }

        if (currentEvent.type == SDL_EVENT_MOUSE_MOTION) {
            if (gameState == GameState::RUNNING) {
                mouseRelativeAccumulator.x += currentEvent.motion.xrel;
                mouseRelativeAccumulator.y += currentEvent.motion.yrel;
                mouseMovedThisFrame = true;
            }
        }

        if (currentEvent.type == SDL_EVENT_MOUSE_BUTTON_DOWN) {
            if (currentEvent.button.button == SDL_BUTTON_LEFT) {
                leftMouseButtonPressed = true;
            }
            if (currentEvent.button.button == SDL_BUTTON_RIGHT) {
                if (gameState == GameState::RUNNING) {
                    activateRepulsor();
                }
            }
        }

        if (currentEvent.type == SDL_EVENT_MOUSE_BUTTON_UP) {
            if (currentEvent.button.button == SDL_BUTTON_LEFT) {
                leftMouseButtonPressed = false;
            }
        }

        if (currentEvent.type == SDL_EVENT_KEY_DOWN) {
            switch (currentEvent.key.key) {
                case SDLK_R:
                    if (gameState != GameState::RUNNING) {
                        resetGame();
                    }
                    break;
                case SDLK_ESCAPE:
                    quit = true;
                    break;
                default:
                    break;
            }
        }

        if (currentEvent.type == SDL_EVENT_WINDOW_RESIZED) {
            windowWidth = currentEvent.window.data1;
            windowHeight = currentEvent.window.data2;
            initScrollingRectangles();
        }
    }
}

void animate() {
    if (gameState != GameState::RUNNING) {
        return;
    }

    for (size_t i = 0; i < scrollingGrid.size(); i++) {
        Rectangle& gridRectangle = scrollingGrid[i];
        gridRectangle.pos += gridRectangle.vel * DT;
        if (gridRectangle.pos.y > (windowHeight + gridRectangle.height / 2.0f)) {
            gridRectangle.pos.y -= gridRectangle.height * scrollingGrid.size();
        }
    }

    if (mouseMovedThisFrame && glm::length(mouseRelativeAccumulator) > 0.0001f) {
        glm::vec2 moveDir = glm::normalize(mouseRelativeAccumulator);
        playerShip.vel += moveDir * (SHIP_ACCELERATION * DT);

        float speed = glm::length(playerShip.vel);
        if (speed > SHIP_MAX_VELOCITY) {
            playerShip.vel = (playerShip.vel / speed) * SHIP_MAX_VELOCITY;
        }
    } else {
        float speed = glm::length(playerShip.vel);
        if (speed > 0.0001f) {
            float newSpeed = std::max(0.0f, speed - SHIP_DECELERATION * DT);
            playerShip.vel = (playerShip.vel / speed) * newSpeed;
        } else {
            playerShip.vel = glm::vec2(0.0f, 0.0f);
        }
    }

    playerShip.pos += playerShip.vel * DT;

    float halfW = playerShip.width / 2.0f;
    float halfH = playerShip.height / 2.0f;
    if (playerShip.pos.x < halfW) {
        playerShip.pos.x = halfW;
        if (playerShip.vel.x < 0) playerShip.vel.x = 0;
    }
    if (playerShip.pos.x > windowWidth - halfW) {
        playerShip.pos.x = windowWidth - halfW;
        if (playerShip.vel.x > 0) playerShip.vel.x = 0;
    }
    if (playerShip.pos.y < halfH) {
        playerShip.pos.y = halfH;
        if (playerShip.vel.y < 0) playerShip.vel.y = 0;
    }
    if (playerShip.pos.y > windowHeight - halfH) {
        playerShip.pos.y = windowHeight - halfH;
        if (playerShip.vel.y > 0) playerShip.vel.y = 0;
    }

    if (leftMouseButtonPressed) {
        playerShootCooldownTimer += DT;
        if (playerShootCooldownTimer >= PLAYER_FIRE_RATE) {
            spawnPlayerProjectile();
            playerShootCooldownTimer = 0.0f;
        }
    } else {
        playerShootCooldownTimer = PLAYER_FIRE_RATE;
    }

    for (size_t i = 0; i < playerProjectiles.size(); ) {
        playerProjectiles[i].pos += playerProjectiles[i].vel * DT;
        if (playerProjectiles[i].pos.y + playerProjectiles[i].radius < 0) {
            playerProjectiles.erase(playerProjectiles.begin() + i);
        } else {
            i++;
        }
    }

    for (int s = 0; s < 3; s++) {
        if (!slices[s].hasActiveEnemy) {
            slices[s].clearTimer += DT;
            if (slices[s].clearTimer >= 3.0f) {
                spawnEnemyInSlice(s);
            }
        }
    }

    for (size_t i = 0; i < enemies.size(); ) {
        Enemy& enemy = enemies[i];
        enemy.rect.pos += enemy.rect.vel * DT;
        enemy.timeSinceEntered += DT;

        if (enemy.timeSinceEntered >= ENEMY_START_SHOOT_DELAY) {
            if (!enemy.hasStartedShooting) {
                enemy.hasStartedShooting = true;
                spawnEnemyProjectiles(enemy);
                enemy.shootTimer = 0.0f;
            } else {
                enemy.shootTimer += DT;
                if (enemy.shootTimer >= ENEMY_FIRE_RATE) {
                    spawnEnemyProjectiles(enemy);
                    enemy.shootTimer = 0.0f;
                }
            }
        }

        if (enemy.rect.pos.y - enemy.rect.height / 2.0f > windowHeight) {
            slices[enemy.sliceIndex].hasActiveEnemy = false;
            slices[enemy.sliceIndex].clearTimer = 0.0f;
            enemies.erase(enemies.begin() + i);
        } else {
            i++;
        }
    }

    for (size_t i = 0; i < enemyProjectiles.size(); ) {
        enemyProjectiles[i].pos += enemyProjectiles[i].vel * DT;
        if (enemyProjectiles[i].pos.x < -100.0f || enemyProjectiles[i].pos.x > windowWidth + 100.0f ||
            enemyProjectiles[i].pos.y < -100.0f || enemyProjectiles[i].pos.y > windowHeight + 100.0f) {
            enemyProjectiles.erase(enemyProjectiles.begin() + i);
        } else {
            i++;
        }
    }

    for (size_t p = 0; p < playerProjectiles.size(); ) {
        bool projectileDestroyed = false;
        for (size_t e = 0; e < enemies.size(); ) {
            if (checkCircleRectangleCollision(playerProjectiles[p], enemies[e].rect)) {
                slices[enemies[e].sliceIndex].hasActiveEnemy = false;
                slices[enemies[e].sliceIndex].clearTimer = 0.0f;
                enemies.erase(enemies.begin() + e);
                totalEnemiesDestroyed++;

                projectileDestroyed = true;
                break;
            } else {
                e++;
            }
        }

        if (projectileDestroyed) {
            playerProjectiles.erase(playerProjectiles.begin() + p);
        } else {
            p++;
        }
    }

    if (totalEnemiesDestroyed >= 3 && enemies.empty()) {
        triggerGameOver(true);
        return;
    }

    for (const auto& proj : enemyProjectiles) {
        if (checkCircleRectangleCollision(proj, playerShip)) {
            triggerGameOver(false);
            return;
        }
    }

    for (const auto& enemy : enemies) {
        if (checkRectangleRectangleCollision(enemy.rect, playerShip)) {
            triggerGameOver(false);
            return;
        }
    }
}

void drawFrame() {
    SDL_SetRenderDrawColor(renderer, backgroundColor.r, backgroundColor.g, backgroundColor.b, backgroundColor.a);
    SDL_RenderClear(renderer);

    for (size_t i = 0; i < scrollingGrid.size(); i++) {
        scrollingGrid[i].draw(renderer);
    }

    if (gameState == GameState::RUNNING) {
        for (auto& enemy : enemies) {
            enemy.rect.draw(renderer);
        }

        for (auto& proj : playerProjectiles) {
            proj.draw(renderer);
        }

        for (auto& proj : enemyProjectiles) {
            proj.draw(renderer);
        }
    }

    playerShip.draw(renderer);

    SDL_RenderPresent(renderer);
}

int main(int argc, char* argv[]) {
    if (!initWindow()) {
        std::cout << "Failed to initialize" << std::endl;
        return -1;
    }

    SDL_zero(currentEvent);

    initScrollingRectangles();

    playerShip = Rectangle(SHIP_WIDTH, SHIP_HEIGHT,
                           glm::vec2(windowWidth / 2.0f, windowHeight - SHIP_HEIGHT / 2.0f),
                           SDL_Color{ 0, 255, 0, 255 });

    for (int i = 0; i < 3; i++) {
        spawnEnemyInSlice(i);
    }

    while (!quit) {
        startTime = SDL_GetTicks();

        processEvents();
        animate();
        drawFrame();

        endTime = SDL_GetTicks();
        Uint64 frameDuration = endTime - startTime;
        if (frameDuration < 16) {
            SDL_Delay(static_cast<Uint32>(16 - frameDuration));
            endTime = SDL_GetTicks();
        }

        DT = (endTime - startTime) / 1000.0f;
        if (DT > 0.05f) DT = 0.05f;
    }

    cleanup();
    return 0;
}